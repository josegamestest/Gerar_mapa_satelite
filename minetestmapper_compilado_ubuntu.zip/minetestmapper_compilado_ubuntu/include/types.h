#include <string>

typedef std::basic_string<unsigned char> ustring;
typedef unsigned int uint;
typedef unsigned char u8;
