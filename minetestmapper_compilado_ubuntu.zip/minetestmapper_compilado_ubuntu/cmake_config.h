// Filled in by the build system

#ifndef CMAKE_CONFIG_H
#define CMAKE_CONFIG_H

#define USE_POSTGRESQL 1
#define USE_LEVELDB 1
#define USE_REDIS 1

#define SHAREDIR "share/minetest"

#endif

