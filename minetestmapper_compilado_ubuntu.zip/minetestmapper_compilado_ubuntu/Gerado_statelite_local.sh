#!/usr/bin/env bash
#by  Jose Anastacio  @josegamestest
#------------------------------------------------------------------------------------------------------------------------------------------------------------------#
caminho1=$(pwd)
caminho_mundo="diretorio_do_mundo"
# Formatar a data e a hora
data_hora=$(date +"%Y-%m-%d_%H-%M-%S")
./minetestmapper -i $caminho_mundo -o ${caminho_mundo}mapa_satelite${data_hora}.png 
